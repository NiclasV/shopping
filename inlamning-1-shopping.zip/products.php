<?php

$products = array(
  array(
    "image"   => "img/fidget_spinner.png",
    "name"    => "Fidget Spinner",
    "price"   => 100,
    "color"   => "Invisible"
  ),
  array(
    "image"   => "img/vr_glasses.png",
    "name"    => "VR-glasses",
    "price"   => 299,
    "color"   => "Black"
  ),
  array(
    "image"   => "img/powerbank.png",
    "name"    => "Power Bank",
    "price"   => 399,
    "color"   => "White"
  ),
  array(
    "image"   => "img/fidget_spinner_gold.png",
    "name"    => "Fidget Spinner Delux",
    "price"   => 999,
    "color"   => "Gold"
  )
); ?>
